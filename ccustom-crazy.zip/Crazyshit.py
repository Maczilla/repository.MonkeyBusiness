'''
    Cumination
    Copyright (C) 2019 Cumination
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmcplugin
from resources.lib import utils
#from resources.lib.adultsite import AdultSite
from resources.lib.customsite import CustomSite

site = CustomSite('Cumination', 'crazyshit')

#site = AdultSite('crazyshit', '[COLOR hotpink]Crazyshit[/COLOR]', 'https://www.crazyshit.com/videos/', 'crazyshit.png', 'crazyshit')

BASE_URL = 'https://xxxtubezoo.com'

@site.register(default_mode=True)
def Main():
    site.add_dir('[COLOR hotpink]Categories[/COLOR]', 'https://www.crazyshit.com/categories/', 'Categories', site.img_cat)
    List('https://xxxtubezoo.com/newest/')
    utils.eod()


@site.register()
def List(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        return None
    match = re.compile(r'(/cnt/medias[^"]+)"\s*title="([^"]+)"\s*c[^>]+.*?container"><img\s*src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, name, img in match:
        name = utils.cleantext(name).title()
        site.add_download_link(name, BASE_URL + videopage, 'Playvid', img, name)
    
    nextp = re.compile('<a href="([^"]+)"><i class="fa fa-angle-right">').search(listhtml)
    if nextp:
        site.add_dir('Next Page', BASE_URL + nextp.group(1), 'List', site.img_next)
    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(25, "[CR]Loading video page[CR]")
    videopage = utils.getHtml(url, '')
    videolink = re.compile(r'<source\s*src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)[0]
    vp.play_from_direct_link(videolink.replace('https', 'http').replace('&amp;', '&'))


@site.register()
def Categories(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile(r'(/category/[^"]+)"\s*title="([^"]+)"\s*class="thumb">.*?container"><img\s*src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for cat, name, img in match:
        catpage = BASE_URL + cat
        site.add_dir(name, catpage, 'List', img)
    utils.eod()
