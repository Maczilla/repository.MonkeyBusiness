import sys
import os
import urllib
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import logging
from operator import itemgetter

def show_tags():
  tag_handle = int(sys.argv[1])
  xbmcplugin.setContent(tag_handle, 'tags')

  for tag in tags:
    iconPath = os.path.join(home, 'logos', tag['icon'])
    li = xbmcgui.ListItem(tag['name'], iconImage=iconPath)
    url = sys.argv[0] + '?tag=' + str(tag['id'])
    xbmcplugin.addDirectoryItem(handle=tag_handle, url=url, listitem=li, isFolder=True)

  xbmcplugin.endOfDirectory(tag_handle)


def show_streams(tag):
  stream_handle = int(sys.argv[1])
  xbmcplugin.setContent(stream_handle, 'streams')
  logging.warning('TAG show_streams!!!! %s', tag)
  for stream in streams[str(tag)]:
    logging.debug('STREAM HERE!!! %s', stream['name'])
    iconPath = os.path.join(home, 'logos', stream['icon'])
    li = xbmcgui.ListItem(stream['name'], iconImage=iconPath)
    xbmcplugin.addDirectoryItem(handle=stream_handle, url=stream['url'], listitem=li)

  xbmcplugin.endOfDirectory(stream_handle)


def get_params():
  """
  Retrieves the current existing parameters from XBMC.
  """
  param = []
  paramstring = sys.argv[2]
  if len(paramstring) >= 2:
    params = sys.argv[2]
    cleanedparams = params.replace('?', '')
    if params[len(params) - 1] == '/':
      params = params[0:len(params) - 2]
    pairsofparams = cleanedparams.split('&')
    param = {}
    for i in range(len(pairsofparams)):
      splitparams = {}
      splitparams = pairsofparams[i].split('=')
      if (len(splitparams)) == 2:
        param[splitparams[0]] = splitparams[1]
  return param


def lower_getter(field):
  def _getter(obj):
    return obj[field].lower()

  return _getter


addon = xbmcaddon.Addon()
home = xbmc.translatePath(addon.getAddonInfo('path'))

tags = [
  {
    'name': 'Live TV',
    'id': 'LiveTV',
    'icon': 'livetv.png'
  }, {
    'name': 'Movies',
    'id': 'Movies',
    'icon': 'movies.png'
  }
]


LiveTV = [{
  'name': 'DR1',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/1628.ts',
  'icon': 'DR 1.png',
  'disabled': False
}, {
  'name': 'DR2',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/2985.ts',
  'icon': 'DR 2.png',
  'disabled': False
}, {
 'name': 'TV 2',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/8038.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'TV2 NEWS',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/1633.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'TV2 ZULU',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/1631.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'TV2 Fri',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/1632.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'TV2 sport',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/3097.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'TV2 CHARLIE',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/3103.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'TV3 Denmark',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/2972.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'TV3+',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/1630.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'TV3 Puls',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/1635.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'TV3SPORT 1',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/3094.ts',
  'icon': '',
  'disabled': False
  }, {
 'name': 'Kanal 4',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/2983.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'KANAL 5',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/1636.ts',
  'icon': '',
  'disabled': False
}, {
 'name': '6 Eren',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/2973.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'CANAL 9 DK',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/2994.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'DK4',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/1629.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'COMEDY CENTRAL',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/3131.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'DR 1 (backup)',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/2984.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'TV 2 (backup)',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/3101.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'TV2 NEWS (backup)',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/2974.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'TV2 ZULU (backup)',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/3096.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'TV2 Fri (backup)',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/3102.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'TV3 (backup)',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/2977.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'DR ULTRA',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/3105.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'DR K',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/3107.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'Cartoon Network',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/3132.ts',
   'icon': '',
  'disabled': False
}, {
 'name': 'Nicklodeon',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/8040.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'ANIMAL PLANET',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/3133.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'DR RAMASJANG',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/3106.ts',
  'icon': '',
  'disabled': False
}, {  
 'name': 'C More First',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/2988.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'National Geographic',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/4924.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'DK 4',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/3108.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'Disney XD',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/2986.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'Nat Geo People HD',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/4353.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'Discovery Channel',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/7564.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'Discovery World',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/17307.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'Eurosport 1',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/17304.ts',
  'icon': '',
  'disabled': False
}, {
 'name': 'EUROSPORT 2',
  'url': 'http://bestbuyiptv.link:6969/live/ussim460@gmail.com/ClEcXJmFMa/17305.ts',
  'icon': '',
  'disabled': False
}]


Movies = [{
 'name': '100 Metros (2016)',
  'url': 'http://bestbuyiptv.link:6969/movie/ussim460@gmail.com/ClEcXJmFMa/13704.mp4',
  'icon': '',
  'disabled': False
}]


streams = {
  'LiveTV': sorted((i for i in LiveTV if not i.get('disabled', False)), key=lower_getter('name')),
  'Movies': sorted((i for i in Movies if not i.get('disabled', False)), key=lower_getter('name')),
  # 'LiveTV': sorted(LiveTV, key=lower_getter('name')),
  # 'Movies': sorted(Movies, key=lower_getter('name')),
}

PARAMS = get_params()
TAG = None
logging.warning('PARAMS!!!! %s', PARAMS)

try:
  TAG = PARAMS['tag']
except:
  pass

logging.warning('ARGS!!!! sys.argv %s', sys.argv)

if TAG == None:
  show_tags()
else:
  show_streams(TAG)
